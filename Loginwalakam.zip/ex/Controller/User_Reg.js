const Bcrypt = require("bcryptjs");
const JWT = require("jsonwebtoken")
//@method Get

//http://localhost:5000/
const GetUser_Reg = (req, res) => {
  return res.render("User_Reg");
};
//@method Post
//http://localhost:5000/
async function PostUser_Reg(req, res) {
  try {
    const { Name, Email, Password } = req.body;
    const Name_KA_checker = /^[A-Za-z]{1,16}$/;
    const Email_KA_checker = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

    // validator
    const NameValidator = Name_KA_checker.test(Name);
    const EmailValidator = Email_KA_checker.test(Email);
    const HashedPassword = await Bcrypt.hash(Password, 10);

    if (NameValidator == true) {
      if (EmailValidator == true) {
        if (Password.length > 4) {
          const User_ACC = {
            Name: Name,
            Email: Email,
            Password: HashedPassword,
          };
          const response = await fetch(
            "https://669b43dc276e45187d34f8ff.mockapi.io/school/Login",
            {
              headers: { "Content-Type": "application/json" },
              method: "POST",
              body: JSON.stringify(User_ACC),
            }
          );

          return res.status(200).send(User_ACC);
        } else {
          return res.send("password kamzoor hai");
        }
      } else {
        return res.send("EMail mai masla hai");
      }
    } else {
      return res.send("Naam Mai NUmber HAi");
    }
  } catch (error) {
    res.send(error);
  }
}





//@method Get
//http://localhost:5000/GetAllUsers
async function GetAllUsers(req, res) {
  const response = await fetch(
    "https://669b43dc276e45187d34f8ff.mockapi.io/school/Login"
  );
  const allUser = await response.json();
  return res.send(allUser);
}


const GetloginUsers = (req, res) => {
  return res.render("Login");
};

//@method Post
//http://localhost:5000/login
async function loginUsers(req, res) {
  try {
    const {Email , Password} = req.body
    const response = await fetch(
      "https://669b43dc276e45187d34f8ff.mockapi.io/school/Login"
    );
    const allUser = await response.json();

    const findUser = allUser.filter(options => options.Email == Email)

return res.send("Login success");



  } catch (error) {
    console.log(error);
  }
}
module.exports = { GetUser_Reg, PostUser_Reg, GetAllUsers, loginUsers ,GetloginUsers};
