const express = require("express");
const app = express();
const dotenv = require("dotenv").config();
app.set("view engine", "ejs");
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
const { GetUser_Reg, PostUser_Reg, GetAllUsers,loginUsers ,GetloginUsers} = require("./Controller/User_Reg");

app.route("/").get(GetUser_Reg).post(PostUser_Reg);
app.route("/getallusers").get(GetAllUsers);
app.route("/Login").get(GetloginUsers).post(loginUsers);


app.listen(process.env.Port, function () {
  console.log(`Server is running on Port: ${process.env.Port}`);
});
